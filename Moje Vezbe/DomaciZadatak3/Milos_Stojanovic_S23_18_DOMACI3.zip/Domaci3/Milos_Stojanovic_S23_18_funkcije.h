#ifndef FUNKCIJE_H
#define FUNKCIJE_H
//Milos Stojanovic S23/18
int hes(char [], int);
void provera(char [], int, int);
void prijava(void);
void registracija(void);

#endif
